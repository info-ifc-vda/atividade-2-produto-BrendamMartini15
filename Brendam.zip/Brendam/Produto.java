public class Produto {

    // Atributos da classe
    private String nome;
    private double valor;
    private int quantidadeEmEstoque;

    // Construtor
    public Produto(String nome, double valor, int quantidadeEmEstoque) {
        this.nome = nome;
        this.valor = valor;
        this.quantidadeEmEstoque = quantidadeEmEstoque;
    }

    // Método para escrever os dados do produto
    public void escreverDados() {
        System.out.println("--- Dados do Produto ---");
        System.out.println("Nome: " + this.nome);
        System.out.println("Valor: R$" + String.format("%.2f", this.valor));
        System.out.println("Quantidade em Estoque: " + this.quantidadeEmEstoque);
    }

    // Método para calcular o valor total do produto em estoque
    public double calcularValorTotal() {
        return this.valor * this.quantidadeEmEstoque;
    }

    // Método para alterar a quantidade em estoque
    public void alterarQuantidade(int alteracao) {
        // Verifica se a alteração não vai resultar em estoque negativo
        if (this.quantidadeEmEstoque + alteracao >= 0) {
            this.quantidadeEmEstoque += alteracao;
            System.out.println("Quantidade em estoque alterada com sucesso.");
        } else {
            System.out.println("Erro: A quantidade em estoque não pode ser negativa.");
        }
    }

    // Exemplo de uso da classe
    public static void main(String[] args) {
        // Cria um novo produto
        Produto p1 = new Produto("Laptop Gamer", 7500.00, 10);

        // Exibe os dados iniciais do produto
        p1.escreverDados();

        // Calcula e exibe o valor total em estoque
        System.out.println("Valor total em estoque: R$" + String.format("%.2f", p1.calcularValorTotal()));

        System.out.println("\n--- Realizando alterações no estoque ---");
        
        // Adiciona 5 unidades ao estoque
        p1.alterarQuantidade(5);
        p1.escreverDados();

        // Remove 12 unidades do estoque
        p1.alterarQuantidade(-12);
        p1.escreverDados();

        // Tenta remover 50 unidades (isso deve falhar)
        p1.alterarQuantidade(-50);
        p1.escreverDados();

        // Exibe o valor total em estoque após as alterações
        System.out.println("\nValor total final em estoque: R$" + String.format("%.2f", p1.calcularValorTotal()));
    }
}